# Secure Testing Repository

This repository contains protected files for internal use only.

## 📦 How to Access Secure Data

1. Ensure you're using an authorized device.
2. Download and install [7-Zip](https://www.7-zip.org/)
3. Double-click `decrypt_secure.bat`
4. Enter the extraction password when prompted (if required)

Unauthorized devices will be denied access based on MAC address.
