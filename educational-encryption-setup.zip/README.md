# 🔐 GitHub Educational Encryption Setup

This project shows how to use `.bat` files to encrypt and decrypt repository content securely.

## 🔧 Setup

- Requires **7-Zip** installed at `C:\Program Files\7-Zip\7z.exe`
- Uses a **MAC address check** for secure decryption
- Encrypted output is `repo_data.7z`

## 🔐 Scripts

- `encrypt_repo.bat` → Compress & encrypt folder
- `decrypt_repo.bat` → Check MAC & decrypt if allowed

## 📁 Workflow

1. Add files to `sample_folder/`
2. Run `encrypt_repo.bat`
3. Commit `repo_data.7z` to your GitHub repo (if you want)
4. Share `decrypt_repo.bat` with authorized machines only

---

**Educational use only.**
